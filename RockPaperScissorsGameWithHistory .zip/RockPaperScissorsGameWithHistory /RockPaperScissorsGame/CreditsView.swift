//  John Chung
//  CreditsView.swift
//  RockPaperScissorsGame
//  A Rock Paper Scissors (RPS) app which lets the user play against computer-generated moves, and includes a Game History of the player's Win and Lose matches.
//  Created by John Jeffrey Chung on 3/22/17.
//  Copyright © 2017 John Jeffrey Chung. All rights reserved.
//  This view will feature the game credits and will include a button to direct the users back to the Game View screen

import UIKit


class CreditsView: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }


}
