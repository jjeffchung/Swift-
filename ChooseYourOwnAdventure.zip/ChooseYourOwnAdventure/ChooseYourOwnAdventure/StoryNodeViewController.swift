//
//  StoryNodeViewController.swift
//  ChooseYourOwnAdventure
//
//  Created by John Jeffrey Chung on 3/15/17.
//  Copyright © 2017 John Jeffrey Chung. All rights reserved.
//

import UIKit

class StoryNodeViewController: UIViewController {
    override func viewDidLoad() {
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Start Over", style: UIBarButtonItemStyle.plain, target: self, action: #selector(StoryNodeViewController.startOver))
        self.navigationItem.title = "Epic Adventure Time"
        
        super.viewDidLoad()
    }
    
    func startOver(){
        self.navigationController!.popToRootViewController(animated: true)
    }
}

