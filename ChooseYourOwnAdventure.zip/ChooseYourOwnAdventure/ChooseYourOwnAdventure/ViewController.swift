//
//  ViewController.swift
//  ChooseYourOwnAdventure
//
//  Created by John Jeffrey Chung on 3/15/17.
//  Copyright © 2017 John Jeffrey Chung. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

